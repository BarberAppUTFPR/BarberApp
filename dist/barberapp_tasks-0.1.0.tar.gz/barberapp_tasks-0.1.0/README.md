﻿example-tasks

Exemplo em Python com 3 tarefas, CLI, testes, lint e build.
